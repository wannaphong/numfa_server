Tests for ChatterBot examples
=============================

This directory contains tests for the ChatterBot example programs
to make sure that things don't break and continue to work as
expected as changes are made to the chatterbot package.
